module com.example.t3fx_lt3 {
    requires javafx.controls;
    requires javafx.fxml;

    exports t3FX_LT3;
}